angular.module("tamsApp")

.service('UserData', function (CacheFactory, $q, $auth, $ionicUser, $ionicPush) {
    var cacheName = 'userCache';
    var itemName = 'user';
    var cache = createCache(cacheName);

    function isAuthenticated() {
        return $auth.isAuthenticated();
    }

    function createCache(name) {
        if (!CacheFactory.get(name)) {
            // or CacheFactory('bookCache', { ... });
            return CacheFactory.createCache(name, {
                deleteOnExpire: 'passive',
                storageMode: 'localStorage'
            });
        }
    }

    return {
        saveUser: function (data) {
            var status = false;
            if (isAuthenticated()) {
                cache.put(itemName, data);
                status = true;
            }

            return status;
        },
        getUser: function () {
            if (isAuthenticated()) {
                return cache.get(itemName);
            }
            
            return false;
        },
        getUserAttrib: function (attrib) {
            return cache.get(itemName)[attrib] || false;
        },
        removeUser: function () {
            cache.destroy();
            $auth.logout();
        },
        identifyUser: function (userData) {
            var deferred = $q.defer();
            var user = $ionicUser.get();
            if (!user.user_id) {
                // Set your user_id here, or generate a random one.
                user.user_id = $ionicUser.generateGUID();
            };
            
            // Metadata
            userData = userData || {};
            angular.extend(user, userData);
            
            // Identify your user with the Ionic User Service
            $ionicUser.identify(user).then(function () {
                console.log('Identified user ' + user.name + '\n ID ' + user.user_id);                
                deferred.resolve();
            });
            
            return deferred.promise;
        },
        registerUserDevice: function () {
            console.log('Ionic Push: Registering user');
            // Register with the Ionic Push service.  All parameters are optional.
            $ionicPush.register({
                canShowAlert: true, //Can pushes show an alert on your screen?
                canSetBadge: true, //Can pushes update app icon badges?
                canPlaySound: true, //Can notifications play a sound?
                canRunActionsOnWake: true, //Can run actions outside the app,
                onNotification: function (notification) {
                    // Handle new push notifications here
                    console.log(notification);
                    return true;
                }
            });
        }
    };
});