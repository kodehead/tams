tams = angular.module('tamsApp');
tams.controller('UserHomeCtrl', function ($scope, $state, $ionicPopup, UserData, $ionicModal) {
    var user = UserData.getUser();
    
    if(user) {
        $scope.user = user;
        $scope.user.image =  $scope.user.image || "img/authors/profile.jpg";
        user = null;
    }else {
        var alertPopup = $ionicPopup.alert({
            title: 'Session Expired',
            template: 'Please log in again!'
        });
        
        alertPopup.then(function(res){
            if(res) {
                $state.go('app.auth');
            }else {
                $state.go('app.splash');
            }
        });
    }        
    
    //group modal
    $ionicModal.fromTemplateUrl('group.html', function ($ionicModal) {
        $scope.group = $ionicModal;
    }, {
        // Use our scope for the scope of the modal to keep it simple
        scope: $scope,
        // The animation we want to use for the modal entrance
        animation: 'slide-in-up'
    });

    //follow modal
    $ionicModal.fromTemplateUrl('follow.html', function ($ionicModal) {
        $scope.follow = $ionicModal;
    }, {
        // Use our scope for the scope of the modal to keep it simple
        scope: $scope,
        // The animation we want to use for the modal entrance
        animation: 'slide-in-up'
    });

    //following modal
    $ionicModal.fromTemplateUrl('following.html', function ($ionicModal) {
        $scope.following = $ionicModal;
    }, {
        // Use our scope for the scope of the modal to keep it simple
        scope: $scope,
        // The animation we want to use for the modal entrance
        animation: 'slide-in-up'
    });
    
});