angular.module("tamsApp", ['ionic', 'ngCordova', 'ionic.service.core', 'ionic.service.push', 'satellizer', 'angular-cache', 'angularMoment'])

        .run(function ($ionicPlatform, UserData) {

            // Identify and register user for push notifications
            var status = UserData.identifyUser({});
            status.then(function () {
                UserData.registerUserDevice();
            });

            $ionicPlatform.ready(function () {
                // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
                // for form inputs)
                if (window.cordova && window.cordova.plugins.Keyboard) {
                    cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
                }
                if (window.StatusBar) {
                    // org.apache.cordova.statusbar required
                    StatusBar.styleDefault();

                }
            });
        })

        .config(['$ionicConfigProvider', function ($ionicConfigProvider) {

                $ionicConfigProvider.tabs.position('bottom'); // other values: top

            }])

        .config(function ($stateProvider, $urlRouterProvider, $ionicConfigProvider, $ionicAppProvider, $authProvider, CacheFactoryProvider) {


            $ionicAppProvider.identify({
                app_id: 'e10462a8',
                api_key: '88dffdf700b54a192eb9fef83c6614c7265d9b8704f08edf',
                dev_push: false
            });

            angular.extend(CacheFactoryProvider.defaults);


            $ionicConfigProvider.views.forwardCache(true);

            $stateProvider

                    .state('app', {
                        abstract: true,
                        url: "/app",
                        templateUrl: "app/layout/menu-layout.html",
                        controller: 'AppCtrl'
                    })

                    .state('app.splash', {
                        url: "/splash",
                        views: {
                            'mainContent': {
                                templateUrl: "app/splash.html"
                            }
                        }
                    })

                    .state('app.auth', {
                        url: "/auth",
                        views: {
                            'mainContent': {
                                templateUrl: "app/auth/auth.html",
                                controller: ''
                            }
                        }
                    });

            // if none of the above states are matched, use this as the fallback
            $urlRouterProvider.otherwise('/app/splash');
        });