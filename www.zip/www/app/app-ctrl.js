angular.module('tamsApp')
.controller('AppCtrl', function ($scope, $state, UserData) {
    $scope.$on("userLogin", function (event, args) {
        $scope.loggedIn = true;
    });
    
    $scope.loggedIn = false;
    if(UserData.getUser()) {
        $scope.loggedIn = true;
    }
    
    $scope.logout = function() {
        UserData.removeUser();
        $scope.loggedIn = false;
        $state.go('app.splash');
    };
});